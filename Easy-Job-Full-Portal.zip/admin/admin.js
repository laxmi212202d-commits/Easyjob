async function loadJobs(){
 const r=await fetch("../functions/api/jobs"); const jobs=await r.json();
 document.getElementById("rows").innerHTML=jobs.map(j=>`<tr><td>${j.id}</td><td>${j.title}</td><td>${j.company}</td><td>${j.type}</td><td>${j.status}</td></tr>`).join("");
}
async function addJob(e){
 e.preventDefault();
 const f=new FormData(e.target), d=Object.fromEntries(f.entries());
 const r=await fetch("../functions/api/jobs",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(d)});
 document.getElementById("msg").textContent=r.ok?"Job published":"Error: "+await r.text();
 if(r.ok){e.target.reset();loadJobs();}
}
loadJobs();