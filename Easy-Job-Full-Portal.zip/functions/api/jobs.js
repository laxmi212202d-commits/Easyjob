export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    "SELECT * FROM jobs WHERE status='published' ORDER BY id DESC"
  ).all();
  return Response.json(results);
}
export async function onRequestPost({ request, env }) {
  const data = await request.json();
  const required = ["title","company","type"];
  for (const k of required) if (!data[k]) return Response.json({error:`Missing ${k}`},{status:400});
  await env.DB.prepare(`INSERT INTO jobs
    (title,company,type,location,salary,qualification,experience,last_date,category,description,apply_url,whatsapp,telegram,status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(data.title,data.company,data.type,data.location||"",data.salary||"",data.qualification||"",
          data.experience||"",data.last_date||"",data.category||"",data.description||"",
          data.apply_url||"",data.whatsapp||"",data.telegram||"","published").run();
  return Response.json({ok:true});
}