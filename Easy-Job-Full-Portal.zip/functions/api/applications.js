export async function onRequestPost({ request, env }) {
  const d=await request.json();
  if(!d.job_id||!d.name||!d.phone) return Response.json({error:"Name, phone and job_id are required"},{status:400});
  await env.DB.prepare(`INSERT INTO applications(job_id,name,email,phone,resume_url)
    VALUES(?,?,?,?,?)`).bind(d.job_id,d.name,d.email||"",d.phone,d.resume_url||"").run();
  return Response.json({ok:true});
}