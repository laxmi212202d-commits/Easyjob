EASY JOB PORTAL
यह एक free static starter portal है।

चलाने के लिए:
1. ZIP extract करें.
2. index.html browser में खोलें.
3. Free hosting के लिए GitHub Pages या Cloudflare Pages पर पूरी folder upload करें.

महत्वपूर्ण:
- अभी jobs demo data हैं.
- Real Admin Panel के लिए secure login और database चाहिए.
- Real job apply links, WhatsApp number, support email, logo और domain बाद में जोड़ें.
- Government/private vacancies publish करने से पहले official source verify करें.
- AdSense लगाने से पहले original content, privacy policy, terms, disclaimer, contact और अन्य eligibility requirements पूरा करें.
