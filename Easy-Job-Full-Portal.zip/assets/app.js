const jobs=[
{id:1,title:"Office Assistant",company:"Demo Private Company",type:"Private",location:"Prayagraj, UP",salary:"₹12,000–18,000",qualification:"12th Pass",lastDate:"30 Sep 2026",category:"Office Jobs"},
{id:2,title:"Customer Support Executive",company:"Demo Services",type:"Private",location:"Work From Home",salary:"₹15,000–22,000",qualification:"12th / Graduate",lastDate:"Open",category:"Customer Support"},
{id:3,title:"Data Entry Operator",company:"Demo BPO",type:"Work From Home",location:"Remote",salary:"₹10,000–20,000",qualification:"12th Pass + Basic Computer",lastDate:"Open",category:"IT & Computer"},
{id:4,title:"Sales Executive",company:"Demo Retail",type:"Part-time",location:"Uttar Pradesh",salary:"₹8,000–15,000",qualification:"10th / 12th Pass",lastDate:"Open",category:"Sales & Marketing"},
{id:5,title:"Government Recruitment Update",company:"Official Notice Required",type:"Government",location:"India",salary:"As per post",qualification:"Check official notification",lastDate:"Check notice",category:"Government"}
];
let activeType="";
function card(j){return `<article class="job"><div class="jobtop"><span class="pill">${j.type}</span><button class="save" onclick="saveJob(${j.id})">♡</button></div><h3>${j.title}</h3><p>🏢 ${j.company}</p><p>📍 ${j.location}</p><p>💰 ${j.salary}</p><p>🎓 ${j.qualification}</p><p>⏳ Last Date: ${j.lastDate}</p><a class="apply" href="job.html?id=${j.id}">View Details & Apply →</a></article>`}
function renderJobs(){
 const q=(document.getElementById("search")?.value||"").toLowerCase(), t=document.getElementById("typeFilter")?.value||activeType;
 let list=jobs.filter(j=>(!t||j.type===t)&&(!q||Object.values(j).join(" ").toLowerCase().includes(q)));
 document.getElementById("jobList").innerHTML=list.length?list.map(card).join(""):"<div class='empty'>कोई job नहीं मिली।</div>";
}
function searchJobs(){document.getElementById("jobs").scrollIntoView({behavior:"smooth"});renderJobs()}
function filterType(t){activeType=t;document.getElementById("typeFilter").value=t;document.getElementById("jobs").scrollIntoView({behavior:"smooth"});renderJobs()}
function saveJob(id){let a=JSON.parse(localStorage.getItem("easy_saved")||"[]");if(!a.includes(id))a.push(id);localStorage.setItem("easy_saved",JSON.stringify(a));alert("Job saved!")}
renderJobs();